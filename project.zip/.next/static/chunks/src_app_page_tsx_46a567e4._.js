(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_35f3635b._.js",
  "static/chunks/node_modules_c722b618._.js"
],
    source: "dynamic"
});
