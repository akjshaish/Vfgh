(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_app_globals_b805903d.css",
  "static/chunks/node_modules_@firebase_database_dist_index_esm2017_5cb37f30.js",
  "static/chunks/node_modules_framer-motion_dist_es_a96fefdc._.js",
  "static/chunks/node_modules_2105522f._.js",
  "static/chunks/src_a985d68b._.js"
],
    source: "dynamic"
});
