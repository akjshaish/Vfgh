
import { config } from 'dotenv';
config();

import '@/ai/flows/prioritize-support-ticket';
import '@/ai/flows/create-subdomain';
